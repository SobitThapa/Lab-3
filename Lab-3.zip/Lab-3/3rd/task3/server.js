const express = require("express");
const path = require("path");
const app = express();
const mongoose = require("mongoose");

mongoose.connect(
  "mongodb+srv://Sobit:1234@cluster0.3pekyal.mongodb.net/MYDATABASE?retryWrites=true&w=majority",
  { useNewUrlParser: true }
);
const db = mongoose.connection;
db.on("error", (error) => console.error(error));
db.once("open", () => console.log("Connected to Database"));

app.use(express.json());

const tasksRouter = require("./routes/tasks");

app.use("/tasks", tasksRouter);

// Serve the "uploads" folder statically
app.use("/uploads", express.static(path.join(__dirname, "uploads")));

app.listen(3000, () => {
  console.log("server Started");
});
